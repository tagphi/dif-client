/**
 * 模拟 合并版本历史列表
 **/
let $scope = {}

$scope.histories = [
  {
    'timestamp': '1536819883948',
    'version': '2',
    'ipfsInfo': {
      'version': 2,
      'ipfsInfo': {
        'path': 'QmYuNupvr9cBeSBo7sr1EgdthshSDFuXCM1Fw5oYDrgVoo',
        'hash': 'QmYuNupvr9cBeSBo7sr1EgdthshSDFuXCM1Fw5oYDrgVoo',
        'size': 260,
        'name': 'device-merged-1536819877325.txt'
      }
    }
  }
]
