/* eslint-disable no-trailing-spaces */
'use strict'

let chaincodeCron = require('./app/cron/chaincode-cron')

chaincodeCron.onTick()
