#!/bin/bash
node install-everything.js $1