/* eslint-disable no-trailing-spaces,padded-blocks,no-new */

let mergeCron = require('./merge-cron')

mergeCron.onTick()
