/* eslint-disable no-trailing-spaces,padded-blocks,no-new */

let mergeCron = require('./chaincode-cron')

mergeCron.onTick()
