package cc

import (
    "fmt"
    "github.com/hyperledger/fabric/core/chaincode/shim"
    pb "github.com/hyperledger/fabric/protos/peer"
)

var logger = shim.NewLogger("cc")

type SimpleChaincode struct {
}

func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response {
    logger.Info("########### example_cc0 Init ###########")

    return shim.Success(nil)
}

// Transaction makes payment of X units from A to B
func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
    logger.Info("########### example_cc0 Invoke ###########")
    return shim.Success(nil)
}

func (t *SimpleChaincode) echo(stub shim.ChaincodeStubInterface, args []string) pb.Response {
    for i, arg := range args {
        logger.Info(fmt.Sprintf("arg[%d]: %s", i, arg))
    }

    return shim.Success(nil)
}