package cc

import (
    "fmt"
    "testing"
    "github.com/hyperledger/fabric/core/chaincode/shim"
)

func TestEcho(t *testing.T) {
    stub := shim.NewMockStub("dif", nil)

    cc := new(SimpleChaincode)

    cc.echo(stub, []string{"arg1", "arg2"})
}