package main

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"cc"
)

var logger = shim.NewLogger("dif")

func main() {
	err := shim.Start(new(cc.SimpleChaincode))

	if err != nil {
		logger.Error("Error starting Simple chaincode: %s", err)
	}
}
